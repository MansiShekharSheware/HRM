package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Owner;
import com.example.demo.service.OwnerService;

@RestController
@RequestMapping("/owners")
public class OwnerController {
    @Autowired
    private OwnerService ownerService;

    @PostMapping
    public Owner createOwner(@RequestBody Owner owner) {
        return ownerService.saveOwner(owner);
    }

    @GetMapping("/{id}")
    public Optional<Owner> getOwnerById(@PathVariable Long id) {
        return ownerService.getOwnerById(id);
    }

    @GetMapping
    public List<Owner> getAllOwners() {
        return ownerService.getAllOwners();
    }

    @GetMapping("/username/{username}")
    public Optional<Owner> getOwnerByUsername(@PathVariable String username) {
        return ownerService.getOwnerByUsername(username);
    }

    @DeleteMapping("/{id}")
    public void deleteOwner(@PathVariable Long id) {
        ownerService.deleteOwner(id);
    }

    @PutMapping("/{id}")
    public Owner updateOwner(@PathVariable Long id, @RequestBody Owner ownerDetails) {
        return ownerService.getOwnerById(id).map(owner -> {
            owner.setUsername(ownerDetails.getUsername());
            owner.setPassword(ownerDetails.getPassword());
            owner.setFirstname(ownerDetails.getFirstname());
            owner.setLastname(ownerDetails.getLastname());
            owner.setEmail(ownerDetails.getEmail());
            owner.setMobile(ownerDetails.getMobile());
            return ownerService.saveOwner(owner);
        }).orElseGet(() -> {
            ownerDetails.setId(id);
            return ownerService.saveOwner(ownerDetails);
        });
    }
}
