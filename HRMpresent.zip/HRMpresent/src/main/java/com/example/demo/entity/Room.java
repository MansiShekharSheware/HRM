package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String type;
    private String status;
    
    @ManyToOne
    @JoinColumn(name = "owner_id")
    private Owner owner;
    
    @ManyToMany(mappedBy = "rooms")
    private Set<Customer> customers = new HashSet<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	public Room() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Room(Long id, String type, String status, Owner owner, Set<Customer> customers) {
		super();
		this.id = id;
		this.type = type;
		this.status = status;
		this.owner = owner;
		this.customers = customers;
	}

	@Override
	public String toString() {
		return "Room [id=" + id + ", type=" + type + ", status=" + status + ", owner=" + owner + ", customers="
				+ customers + "]";
	}
    
    // Getters and Setters
    
    
}