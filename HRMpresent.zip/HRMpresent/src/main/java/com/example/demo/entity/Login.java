package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Login {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "owner_id", referencedColumnName = "id", nullable = true)
    private Owner owner;
    
    @OneToOne
    @JoinColumn(name = "customer_id", referencedColumnName = "id", nullable = true)
    private Customer customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Login(Long id, Owner owner, Customer customer) {
		super();
		this.id = id;
		this.owner = owner;
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Login [id=" + id + ", owner=" + owner + ", customer=" + customer + "]";
	}
    
    // Getters and Setters
    
}