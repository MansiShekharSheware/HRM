package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Owner;

public interface OwnerService {
    Owner saveOwner(Owner owner);
    Optional<Owner> getOwnerById(Long id);
    List<Owner> getAllOwners();
    Optional<Owner> getOwnerByUsername(String username);
    void deleteOwner(Long id);
}
